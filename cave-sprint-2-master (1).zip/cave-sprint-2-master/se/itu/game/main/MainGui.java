package se.itu.game.main;

import se.itu.game.gui.MainFrame;

public class MainGui {

  public static void main(String[] args) {
    MainFrame mainFrame = new MainFrame();
    mainFrame.run();
  }
  
}
